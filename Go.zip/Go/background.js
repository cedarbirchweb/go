chrome.app.runtime.onLaunched.addListener(function() {
// STEP 2: Create an app window based on window.html that is 800x800

});
