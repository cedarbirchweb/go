// http://stackoverflow.com/questions/29118791/how-to-move-an-element-via-arrow-keys-continuously-smoothly
// Thanks to http://stackoverflow.com/users/1490904/pebbl
// http://jsfiddle.net/7a106ck7/1/

document.addEventListener("DOMContentLoaded", function() {
		// store key codes and currently pressed ones
		var keys = {};
				keys.UP = 38;
				keys.LEFT = 37;
				keys.RIGHT = 39;
				keys.DOWN = 40;

		// store reference to car's position and element
		var car = {
				x: 100,
				y: 100,
				speedMultiplier: 10,
				element: document.getElementById("car")
		};

		// key detection (better to use addEventListener, but this will do)
		document.body.onkeyup =
		document.body.onkeydown = function(e){
				if (e.preventDefault) {
						e.preventDefault();
				}
				else {
						e.returnValue = false;
				}
				var kc = e.keyCode || e.which;
				keys[kc] = e.type == 'keydown';
		};

		// car movement update
		var moveCar = function(dx, dy){
				car.x += (dx||0) * car.speedMultiplier;
				car.y += (dy||0) * car.speedMultiplier;
				car.element.style.left = car.x + 'px';
				car.element.style.top = car.y + 'px';
		};

	// car rotation
	var rotateCar = function(deg){
				car.element.style.transform = 'rotate(' + deg + 'deg)';
		};


		// car control
		var detectCarMovement = function(){
				if ( keys[keys.LEFT] ) {
						moveCar(-1, 0);
						rotateCar(270);
				}
				if ( keys[keys.RIGHT] ) {
						moveCar(1, 0);
						rotateCar(90);
				}
				if ( keys[keys.UP] ) {
						moveCar(0, -1);
						rotateCar(0);
				}
				if ( keys[keys.DOWN] ) {
						moveCar(0, 1);
						rotateCar(180);
				}
		};

		// Update current position on screen
		moveCar();

		// Game loop
		setInterval(function(){
				detectCarMovement();
		}, 1000/24);
});
